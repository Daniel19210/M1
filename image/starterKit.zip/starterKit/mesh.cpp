#include "mesh.h"
#include <GL/glut.h>
#include <iostream>
#include <vector>
// #include "../armadillo/include/armadillo"


//using namespace arma;
using namespace std;

	
//=========================================	
Mesh::Mesh()	
{
}

Mesh::~Mesh()
{
}
